# 教会签到系统 v4.0 - 部署包

## 📦 包内容

### 文件结构
```
deployment/
├── server/                         # 后端服务完整项目
│   ├── app.js                     # Express 应用主文件
│   ├── db.js                      # 数据库配置
│   ├── package.json               # Node依赖配置
│   └── scripts/                   # 工具脚本
│       ├── add_remark_column.js   # 数据库迁移脚本
│       └── ...其他脚本
├── client-dist/                    # 前端编译输出（已构建）
│   ├── index.html                 # 入口HTML
│   ├── assets/                    # CSS、JS、图片资源
│   └── ...编译后的文件
├── DEPLOYMENT_GUIDE.md            # 详细部署指南
├── README.md                      # 本文件
├── deploy.bat                     # Windows快速部署脚本
└── deploy.sh                      # Linux/MacOS快速部署脚本
```

## 🚀 快速开始

### Windows用户

1. **运行部署脚本**
   ```bash
   deploy.bat
   ```
   脚本会自动检查环境并启动服务

### Linux/MacOS用户

1. **运行部署脚本**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

### 手动部署

1. **进入后端目录并安装依赖**
   ```bash
   cd server
   npm install
   ```

2. **配置数据库** （编辑 `server/db.js`）
   ```javascript
   host: 'localhost',
   user: 'root',
   password: 'your_password',
   database: 'church_db'
   ```

3. **创建数据库和表**
   ```bash
   mysql -u root -p < ../path/to/sql/init.sql
   ```

4. **运行数据库迁移**
   ```bash
   node scripts/add_remark_column.js
   ```

5. **启动服务**
   ```bash
   npm start
   ```
   服务将运行在 `http://localhost:3000`

## ✨ 新增功能说明

### 1. 员工备注功能
- 新增 `remark` 字段用于记录备注信息
- 员工列表支持直接编辑备注
- 数据库已自动迁移该列

### 2. 多人同号支持
- **注册阶段**：允许同一手机号注册多个不同的人员
- **签到阶段**：输入手机号时，若存在多人会弹出选择对话框
- **使用场景**：支持家庭成员共用手机号（如家长手机号对应多个小孩）

### 3. UI改进
- 管理员登录页图标边框修复为圆形图样
- 优化错误提示信息
- 改进表单验证逻辑

## 🔐 部署前检查清单

- [ ] Node.js 已安装 (v14+)
- [ ] MySQL 已安装并运行
- [ ] 数据库连接信息已配置
- [ ] front-end dist 文件已生成 ✓
- [ ] 所有依赖已准备就绪 ✓

## 📊 系统架构

```
┌─────────────────────────────────────┐
│         前端 (Vue 3 + Vite)         │
│    client-dist (静态文件)           │
└──────────────┬──────────────────────┘
               │ HTTP/HTTPS
┌──────────────▼──────────────────────┐
│    后端 (Express.js + Node.js)      │
│  ├─ REST API                        │
│  ├─ 静态文件服务                    │
│  └─ 数据库通信                      │
└──────────────┬──────────────────────┘
               │ TCP 3306
┌──────────────▼──────────────────────┐
│         MySQL 数据库                 │
│    (church_db)                      │
└─────────────────────────────────────┘
```

## 📝 默认凭证

| 用途 | 用户名 | 密码 | 说明 |
|------|--------|------|------|
| 管理员登陆 | admin | (初始密码) | 首次部署后需要修改 |

## 🔧 常见问题

### Q: 如何修改API端口？
A: 编辑 `server/app.js` 最后一行，修改监听端口号

### Q: 如何使用HTTPS？
A: 使用Nginx进行反向代理配置SSL证书

### Q: 如何备份数据库？
A: 
```bash
mysqldump -u root -p church_db > backup.sql
```

### Q: 部署后如何访问系统？
A: 
- 员工签到: `http://localhost:3000`
- 管理员登录: `http://localhost:3000/admin`
- 注册新员工: `http://localhost:3000/register`

## 📞 技术支持

支持文档: 查看 `DEPLOYMENT_GUIDE.md`

---

**版本**: 4.0.0  
**发布日期**: 2026-02-06  
**部署日期**: [待部署]
